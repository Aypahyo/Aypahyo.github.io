﻿using System.Collections.Generic;
using NUnit.Framework;
using TicTacToeGUI;

namespace TicTacToeTest
{
    [TestFixture]
    class TicTacToeIntegration
    {
        /*
         * 00	10	20
         * 01	11	21
         * 02	12	22
         */

        [Test]
        public void mapIsCreatedEmpty()
        {
            var vm = new MainWindowViewModel();

            foreach (char[] row in vm.MAP)
            {
                foreach (char field in row)
                {
                    Assert.AreEqual(' ', field);
                }
            }
        }

        [Test]
        public void oWinTopRow()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map22", "map00", "map01", "map10", "map11", "map20" });
            Assert.AreEqual('O', getWinner(vm));
        }

        [Test]
        public void noWinGame()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map00", "map01", "map02", "map11", "map10", "map20", "map21", "map22", "map12" });
            Assert.AreEqual(' ', getWinner(vm));
        }

        [Test]
        public void xWinTopRow()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map00", "map01", "map10", "map11", "map20" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinMiddleRow()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map01", "map00", "map11", "map10", "map21" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinBottomRow()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map02", "map00", "map12", "map10", "map22" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinLeftCol()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map00", "map10", "map01", "map11", "map02" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinMiddleCol()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map10", "map20", "map11", "map21", "map12" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinRightCol()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map20", "map10", "map21", "map11", "map22" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinFallingDiagonal()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map00", "map10", "map11", "map12", "map22" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void xWinRisingDiagonal()
        {
            var vm = new MainWindowViewModel();
            clickSequence(vm, new string[] { "map02", "map10", "map11", "map12", "map20" });
            Assert.AreEqual('X', getWinner(vm));
        }

        [Test]
        public void controlAllSequences()
        {
            uint[] Expect = new uint[] { 0, 0, 0, 0, 0, /* 5 moves */ 1440, 5328, 47952, 72576, 81792, /* draw */ 46080 };
            uint[] Actual = new uint[] { /*0 moves */0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            uint error = 0;

            List<string[]> allPossibleSequences = TicTacToeGenerator.allPossibleSequences();
                

            foreach (string[] clicksequence in allPossibleSequences)
            {
                var vm = new MainWindowViewModel();
                clickSequence(vm, clicksequence);
                if (clicksequence.GetLength(0) > 9)
                {
                    ++error;
                }
                else
                {
                    switch (getWinner(vm))
                    {
                        case 'X': ++Actual[clicksequence.GetLength(0)]; break;
                        case 'O': ++Actual[clicksequence.GetLength(0)]; break;
                        case ' ': ++Actual[10]; break;
                        default: ++error; break;
                    }
                }
            }

            for (uint i = 0; i <= 10; ++i)
            {
                Assert.AreEqual(Expect[i], Actual[i], "Value not expected for Index Nr.: " + i.ToString());
            }
            Assert.AreEqual(0, error);
        }

        private bool clickSequence(MainWindowViewModel vm, string[] seq)
        {
            bool r = true;
            foreach (string buttonName in seq)
            {
                if (vm.mapClick(buttonName) == false)
                {
                    r = false;
                }
            }
            return r;
        }

        private char getWinner(MainWindowViewModel vm)
        {
            switch (vm.Systemstate)
            {
                case "Player X has won the game.": return 'X';
                case "Player O has won the game.": return 'O';
                case "The game ended in a tie.": return ' ';
                default: return 'E';
            }
        }

        

    }
}
