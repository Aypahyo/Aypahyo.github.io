﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using TicTacToeGUI;


namespace TicTacToeTest
{
    class TicTacToeGenerator
    {
        private string[] bNames = new string[] { "map00", "map01", "map02", "map10", "map11", "map12", "map20", "map21", "map22" };

        public static List<string[]> allPossibleSequences()
        {
            return new TicTacToeGenerator().buildAllPossibleSequences();
        }

        private List<string[]> buildAllPossibleSequences()
        {
            ConcurrentBag<string[]> firstClicks = new ConcurrentBag<string[]>();
            Parallel.ForEach(bNames, (bName) =>
            {
                firstClicks.Add(new string[] { bName });
            });
            return buildRecursiveSequences(firstClicks).ToList();
        }

        private ConcurrentBag<string[]> buildRecursiveSequences(ConcurrentBag<string[]> partialSequences)
        {
            var final = new ConcurrentBag<string[]>();
            var partial = new ConcurrentBag<string[]>();

            Parallel.ForEach(partialSequences, (sequence) =>
            {
                foreach (string bName in bNames)
                {
                    var vm = new MainWindowViewModel(sequence);
                    if (vm.mapClick(bName))
                    {
                        string[] newSeq = new string[sequence.Length + 1];
                        Array.Copy(sequence, newSeq, sequence.Length);
                        newSeq[sequence.Length] = bName;
                        switch (vm.Systemstate)
                        {
                            case "Player X has won the game.":
                            case "Player O has won the game.":
                            case "The game ended in a tie.":
                                final.Add(newSeq);
                                break;
                            default:
                                partial.Add(newSeq);
                                break;
                        }
                    }
                }
            });

            if (partial.Count > 0)
            {
                foreach (var item in buildRecursiveSequences(partial))
                {
                    final.Add(item);
                }
            }
            return final;
        }
    }
}
