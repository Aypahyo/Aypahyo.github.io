﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace TicTacToeGUI
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public Char[][] MAP { get { return _map_jagged; } }
        public String Systemstate { get {
                if (' ' != _winner) return "Player " + _winner + " has won the game.";
                if (turn > 9 ) return "The game ended in a tie.";
                return "Player " + _icons[(turn)% 2] + " has to move.";
            } }

        private void notify(String property) 
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
                PropertyChanged(this, new PropertyChangedEventArgs("Systemstate"));
            }
        }
        
        private Char[][] _map_jagged = {
                                       new Char[]{ ' ', ' ', ' ' }, 
                                       new Char[]{ ' ', ' ', ' ' }, 
                                       new Char[]{ ' ', ' ', ' ' }
                                       };


        private uint turn = 1;
        private Char[] _icons = { 'O', 'X' };
        private Char _winner = ' ';

        public MainWindowViewModel()
        {
        }

        public MainWindowViewModel(string[] sequence)
        {
            foreach (string buttonName in sequence)
            {
                mapClick(buttonName);
            }
        }

        public bool mapClick(string name)
        {
                int col = name[3] - '0';
                int row = name[4] - '0';
                return mapProcess(col, row);
        }

        public bool mapProcess(int col, int row)
        {
            if (GAMETryMarkMap(col, row, _icons[turn % 2]))
            {
                notify("MAP");
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool GAMETryMarkMap(int col, int row, Char mark)
        {
            bool changed;
            if (' ' == _map_jagged[col][row] && ' ' == _winner)
            {
                GAMEMark(col, row, mark);
                changed = true;
            }
            else
            {
                changed = false;
            }
            return changed;
        }

        private void GAMEMark(int col, int row, Char mark)
        {
            uint n;
            _map_jagged[col][row] = mark;
            ++turn;
            for (n = 0; n < 3; ++n)
            {
                if (_map_jagged[n][0] != ' ' && _map_jagged[n][0] == _map_jagged[n][1] && _map_jagged[n][0] == _map_jagged[n][2]) _winner = _map_jagged[n][0];
                if (_map_jagged[0][n] != ' ' && _map_jagged[0][n] == _map_jagged[1][n] && _map_jagged[0][n] == _map_jagged[2][n]) _winner = _map_jagged[0][n];
            }
            if (_map_jagged[0][0] != ' ' && _map_jagged[0][0] == _map_jagged[1][1] && _map_jagged[0][0] == _map_jagged[2][2]) _winner = _map_jagged[0][0];
            if (_map_jagged[0][2] != ' ' && _map_jagged[0][2] == _map_jagged[1][1] && _map_jagged[0][2] == _map_jagged[2][0]) _winner = _map_jagged[0][2];
        }
    }
}
