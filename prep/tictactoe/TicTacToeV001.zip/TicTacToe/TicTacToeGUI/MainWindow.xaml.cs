﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace TicTacToeGUI
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MainWindowViewModel vm;
        
        public MainWindow()
        {
            this.DataContext = this.vm = new MainWindowViewModel();
            InitializeComponent();
        }

        public void mapClick(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                vm.mapClick((sender as Button).Name);
            }
        }
    }
}
