﻿namespace TicTacToeGUI
{
    using System.ComponentModel;
    using TicTacToeGame;

    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private Game game;
        
        public MainWindowViewModel()
        {
            this.Initialise(new Human('X'), new Human('O'));
        }

        public MainWindowViewModel(string[] sequence)
        {
            this.Initialise(new Human('X'), new Human('O'));
            foreach (string buttonName in sequence)
            {
                this.UiMapClick(buttonName);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public char[][] MAP
        {
            get
            {
                return this.game.Map;
            }
        }

        public string Systemstate
        {
            get
            {
                if (' ' != this.game.Winner)
                {
                    return "Player " + this.game.Winner + " has won the game.";
                }

                if (this.game.Turn > 9)
                {
                    return "The game ended in a tie.";
                }

                return "Player " + this.game.Next.Icon + " has to move.";
            }
        }

        public bool UiMapClick(string name)
        {
            bool ok;
            if (this.game.Next is Human)
            {
                int col = name[3] - '0';
                int row = name[4] - '0';
                ok = (this.game.Next as Human).MapClick(col, row);
            }
            else
            {
                ok = false;
            }

            return ok;
        }

        public bool UiControlClick(string name)
        {
            bool ok = true;
            switch (name)
            {
                case "HumanVsHuman":
                    this.Initialise(new Human('X'), new Human('O'));
                    break;
                case "HumanVsComputer":
                    this.Initialise(new Human('X'), new ComputerPlayer('B'));
                    break;
                case "ComputerVsHuman":
                    this.Initialise(new ComputerPlayer('A'), new Human('O'));
                    break;
                case "ComputerVsComputer":
                    this.Initialise(new ComputerPlayer('A'), new ComputerPlayer('B'));
                    break;
                default:
                    ok = false;
                    break;
            }

            return ok;
        }

        private void Initialise(IPlayer one, IPlayer two)
        {
            this.game = new Game();
            one.Register(this.game);
            two.Register(this.game);
            this.game.Changed += this.NotifyAll;
            this.game.StartGame();
            this.NotifyAll();
        }

        private void NotifyAll()
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs("MAP"));
                this.PropertyChanged(this, new PropertyChangedEventArgs("Systemstate"));
            }
        }
    }
}
