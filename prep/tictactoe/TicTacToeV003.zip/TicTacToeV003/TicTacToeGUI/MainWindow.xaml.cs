﻿namespace TicTacToeGUI
{
    using System.Windows;
    using System.Windows.Controls;

    public partial class MainWindow : Window
    {
        private MainWindowViewModel vm;
        
        public MainWindow()
        {
            this.vm = new MainWindowViewModel();
            this.DataContext = this.vm;
            this.InitializeComponent();
        }

        public void MapClick(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                this.vm.UiMapClick((sender as Button).Name);
            }
        }

        private void ControlClick(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                this.vm.UiControlClick((sender as Button).Name);
            }
        }
    }
}
