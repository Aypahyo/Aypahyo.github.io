﻿namespace TicTacToeGame
{
    public delegate void ChangedEventHandler();

    public interface IGame
    {
        event ChangedEventHandler Changed;

        char[][] Map { get; }

        uint Turn { get; }

        char Winner { get; }

        IPlayer Next { get; }

        void JoinGame(IPlayer player);

        bool TryMarkMap(int col, int row);
    }
}
