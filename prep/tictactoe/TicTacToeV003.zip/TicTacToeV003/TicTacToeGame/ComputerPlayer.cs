﻿namespace TicTacToeGame
{
    using System;
using System.Collections.Generic;

    public class ComputerPlayer : IPlayer
    {
        private IGame game;
        private Random rnd;
        private List<KeyValuePair<int, int>> mapPoints;

        public ComputerPlayer(char sign)
        {
            this.CreateMapPoints();
            this.Icon = sign;
            this.rnd = new Random();
        }

        public char Icon { get; set; }

        public void Register(IGame game)
        {
            this.game = game;
            this.game.JoinGame(this);
            this.game.Changed += this.MakeMove;
        }

        private void MakeMove()
        {
            while (this.game.Winner == ' ' && this.game.Next == this && this.game.Turn < 10 && this.mapPoints.Count > 0)
            {
                int index = this.rnd.Next(this.mapPoints.Count);
                KeyValuePair<int, int> mark = this.mapPoints[index];
                this.mapPoints.Remove(mark);
                this.game.TryMarkMap(mark.Key, mark.Value);
            }
        }

        private void CreateMapPoints()
        {
            this.mapPoints = new List<KeyValuePair<int, int>>();
            for (int c = 0; c < 3; ++c)
            {
                for (int r = 0; r < 3; ++r)
                {
                    this.mapPoints.Add(new KeyValuePair<int, int>(c, r));
                }
            }
        }
    }
}
