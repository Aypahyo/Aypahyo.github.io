﻿namespace TicTacToeGame
{
    public class Human : IPlayer
    {
        private IGame game;

        public Human(char sign)
        {
            this.Icon = sign;
        }

        public char Icon { get; set; }

        public bool MapClick(int col, int row)
        {
            bool ok = false;
            if (null != this.game)
            {
                ok = this.game.TryMarkMap(col, row);
            }

            return ok;           
        }

        public void Register(IGame game)
        {
            this.game = game;
            game.JoinGame(this);
        }
    }
}
