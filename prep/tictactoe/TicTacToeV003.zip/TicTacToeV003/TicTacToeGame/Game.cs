﻿namespace TicTacToeGame
{
    using System.Collections.Generic;

    public class Game : IGame
    {
        private List<IPlayer> player = new List<IPlayer>(2);
        private uint turn = 1;
        private char winner = ' ';
        private char[][] mapJagged = 
        {
            new char[] { ' ', ' ', ' ' },
            new char[] { ' ', ' ', ' ' },
            new char[] { ' ', ' ', ' ' }
        };

        public event ChangedEventHandler Changed;

        public char[][] Map
        { 
            get { return this.mapJagged; } 
        }

        public uint Turn
        {
            get { return this.turn; }
        }

        public char Winner
        {
            get { return this.winner; }
        }

        public IPlayer Next 
        {
            get
            {
                return this.player[(int)(this.turn + 1) % 2];
            }
        }

        public void JoinGame(IPlayer player)
        {
            this.player.Add(player);
            this.Notify();
        }

        public bool TryMarkMap(int col, int row)
        {
            bool isFree = ' ' == this.Map[col][row];
            bool isRunning = ' ' == this.Winner;
            if (isFree && isRunning)
            {
                this.Mark(col, row);

                this.Notify();
            }

            return isFree && isRunning;
        }

        public void StartGame()
        {
            this.Notify();
        }

        private void Mark(int col, int row)
        {
            uint n;
            this.Map[col][row] = this.Next.Icon;
            ++this.turn;
            for (n = 0; n < 3; ++n)
            {
                if (this.Map[n][0] != ' ' && this.Map[n][0] == this.Map[n][1] && this.Map[n][0] == this.Map[n][2])
                {
                    this.winner = this.Map[n][0];
                }

                if (this.Map[0][n] != ' ' && this.Map[0][n] == this.Map[1][n] && this.Map[0][n] == this.Map[2][n])
                {
                    this.winner = this.Map[0][n];
                }
            }

            if (this.Map[0][0] != ' ' && this.Map[0][0] == this.Map[1][1] && this.Map[0][0] == this.Map[2][2])
            {
                this.winner = this.Map[0][0];
            }

            if (this.Map[0][2] != ' ' && this.Map[0][2] == this.Map[1][1] && this.Map[0][2] == this.Map[2][0])
            {
                this.winner = this.Map[0][2];
            }
        }

        private void Notify()
        {
            if (this.Changed != null)
            {
                this.Changed();
            }
        }
    }
}
