﻿namespace TicTacToeGame
{
    public interface IPlayer
    {
        char Icon { get; set; }

        void Register(IGame game);
    }
}
