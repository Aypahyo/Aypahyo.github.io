﻿namespace TicTacToe_IntegrationTest
{
    using System.Collections.Generic;
    using NUnit.Framework;
    using TicTacToeGUI;

    [TestFixture]
    public class TicTacToeIntegration
    {
        /*
         * 00   10   20
         * 01   11   21
         * 02   12   22
         */

        [Test]
        public void MapIsCreatedEmpty()
        {
            var vm = this.CreateHumanVsHumanGame();

            foreach (char[] row in vm.MAP)
            {
                foreach (char field in row)
                {
                    Assert.AreEqual(' ', field);
                }
            }
        }

        [Test]
        public void PlayerTextChanges()
        {
            var vm = this.CreateHumanVsHumanGame();
            Assert.IsTrue(vm.Systemstate.Contains("Player X"));
            this.ClickSequence(vm, new string[] { "map22" });
            Assert.IsTrue(vm.Systemstate.Contains("Player O"));
            this.ClickSequence(vm, new string[] { "map00" });
            Assert.IsTrue(vm.Systemstate.Contains("Player X"));
        }

        [Test]
        public void OWinTopRow()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map22", "map00", "map01", "map10", "map11", "map20" });
            Assert.AreEqual('O', this.GetWinner(vm));
        }

        [Test]
        public void NoWinGame()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map00", "map01", "map02", "map11", "map10", "map20", "map21", "map22", "map12" });
            Assert.AreEqual(' ', this.GetWinner(vm));
        }

        [Test]
        public void XWinTopRow()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map00", "map01", "map10", "map11", "map20" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinMiddleRow()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map01", "map00", "map11", "map10", "map21" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinBottomRow()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map02", "map00", "map12", "map10", "map22" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinLeftCol()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map00", "map10", "map01", "map11", "map02" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinMiddleCol()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map10", "map20", "map11", "map21", "map12" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinRightCol()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map20", "map10", "map21", "map11", "map22" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinFallingDiagonal()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map00", "map10", "map11", "map12", "map22" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void XWinRisingDiagonal()
        {
            var vm = this.CreateHumanVsHumanGame();
            this.ClickSequence(vm, new string[] { "map02", "map10", "map11", "map12", "map20" });
            Assert.AreEqual('X', this.GetWinner(vm));
        }

        [Test]
        public void ControlAllSequences()
        {
            uint[] expect = new uint[] { 0, 0, 0, 0, 0, /* 5 moves */ 1440, 5328, 47952, 72576, 81792, /* draw */ 46080 };
            uint[] actual = new uint[] { /*0 moves */0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            uint error = 0;

            List<string[]> allPossibleSequences = TicTacToeGenerator.AllPossibleSequences();

            foreach (string[] clicksequence in allPossibleSequences)
            {
                var vm = this.CreateHumanVsHumanGame();
                this.ClickSequence(vm, clicksequence);
                if (clicksequence.GetLength(0) > 9)
                {
                    ++error;
                }
                else
                {
                    switch (this.GetWinner(vm))
                    {
                        case 'X': 
                            ++actual[clicksequence.GetLength(0)]; 
                            break;
                        case 'O': 
                            ++actual[clicksequence.GetLength(0)]; 
                            break;
                        case ' ': 
                            ++actual[10]; 
                            break;
                        default: 
                            ++error; 
                            break;
                    }
                }
            }

            for (uint i = 0; i <= 10; ++i)
            {
                Assert.AreEqual(expect[i], actual[i], "Value not expected for Index Nr.: " + i.ToString());
            }

            Assert.AreEqual(0, error);
        }

        private MainWindowViewModel CreateHumanVsHumanGame()
        {
            MainWindowViewModel vm = new MainWindowViewModel();
            return vm;
        }

        private bool ClickSequence(MainWindowViewModel vm, string[] seq)
        {
            bool r = true;
            foreach (string buttonName in seq)
            {
                if (vm.UiMapClick(buttonName) == false)
                {
                    r = false;
                }
            }

            return r;
        }

        private char GetWinner(MainWindowViewModel vm)
        {
            switch (vm.Systemstate)
            {
                case "Player X has won the game.": return 'X';
                case "Player O has won the game.": return 'O';
                case "The game ended in a tie.": return ' ';
                default: return 'E';
            }
        }
    }
}
