﻿namespace TicTacToe_IntegrationTest
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TicTacToeGUI;

    public class TicTacToeGenerator
    {
        private string[] buttonNames = new string[] { "map00", "map01", "map02", "map10", "map11", "map12", "map20", "map21", "map22" };

        public static List<string[]> AllPossibleSequences()
        {
            return new TicTacToeGenerator().BuildAllPossibleSequences();
        }

        private List<string[]> BuildAllPossibleSequences()
        {
            ConcurrentBag<string[]> firstClicks = new ConcurrentBag<string[]>();
            Parallel.ForEach(
                this.buttonNames, 
                (name) => { firstClicks.Add(new string[] { name }); });
            return this.BuildRecursiveSequences(firstClicks).ToList();
        }

        private ConcurrentBag<string[]> BuildRecursiveSequences(ConcurrentBag<string[]> partialSequences)
        {
            var final = new ConcurrentBag<string[]>();
            var partial = new ConcurrentBag<string[]>();

            Parallel.ForEach(
                partialSequences, 
                (sequence) =>
            {
                foreach (string bName in buttonNames)
                {
                    var vm = new MainWindowViewModel(sequence);
                    if (vm.UiMapClick(bName))
                    {
                        string[] newSeq = new string[sequence.Length + 1];
                        Array.Copy(sequence, newSeq, sequence.Length);
                        newSeq[sequence.Length] = bName;
                        switch (vm.Systemstate)
                        {
                            case "Player X has won the game.":
                            case "Player O has won the game.":
                            case "The game ended in a tie.":
                                final.Add(newSeq);
                                break;
                            default:
                                partial.Add(newSeq);
                                break;
                        }
                    }
                }
            });

            if (partial.Count > 0)
            {
                foreach (var item in this.BuildRecursiveSequences(partial))
                {
                    final.Add(item);
                }
            }

            return final;
        }
    }
}
