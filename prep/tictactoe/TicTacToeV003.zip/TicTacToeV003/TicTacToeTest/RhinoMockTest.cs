﻿namespace StackOverFlow
{
    using NUnit.Framework;
    using Rhino.Mocks;
    using Rhino.Mocks.Interfaces;

    public delegate void EventHandler();

    public interface IHasEvent
    {
        event EventHandler InterfaceEvent;
    }

    public class ClassUnderTest
    {
        public ClassUnderTest(IHasEvent hasEvent)
        {
            this.EventCounter = 0;
            hasEvent.InterfaceEvent += this.IncrementCounter;
        }

        public int EventCounter { get; set; }

        private void IncrementCounter()
        {
            ++this.EventCounter;
        }
    }

    [TestFixture]
    public class RhinoMockTest
    {
        [Test]
        public void TestEventRaising()
        {
            IHasEvent mocked = MockRepository.GenerateMock<IHasEvent>();
            ClassUnderTest cut = new ClassUnderTest(mocked);
            mocked.Raise(m => m.InterfaceEvent += null);

            Assert.AreEqual(1, cut.EventCounter);          
        }
    }
}
