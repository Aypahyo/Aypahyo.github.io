﻿namespace TicTacToe_UnitTest
{
    using System;
    using System.Collections.Generic;
    using NUnit.Framework;
    using Rhino.Mocks;
    using TicTacToeGame;

    [TestFixture]
    public class ComputerPlayerTest
    {
        [Test]
        public void ShouldNotMoveInCaseOf_Tie()
        {
            ComputerPlayer player = new ComputerPlayer('X');
            IGame mock = MockRepository.GenerateMock<IGame>();
            this.SetupMockSimple(mock, ' ', 10, player);
            mock.Expect(x => x.TryMarkMap(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Never();
            player.Register(mock);
            mock.Raise(x => x.Changed += null);
            mock.VerifyAllExpectations();
        }

        [Test]
        public void ShouldNotMoveInCaseOf_OtherPlayersTurn()
        {
            ComputerPlayer player = new ComputerPlayer('X');
            ComputerPlayer other = new ComputerPlayer('O');
            IGame mock = MockRepository.GenerateMock<IGame>();
            this.SetupMockSimple(mock, ' ', 1, other);
            mock.Expect(x => x.TryMarkMap(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Never();
            player.Register(mock);
            mock.Raise(x => x.Changed += null);
            mock.VerifyAllExpectations();
        }

        [Test]
        public void ShouldNotMoveInCaseOf_GameHasWinner()
        {
            ComputerPlayer player = new ComputerPlayer('X');
            IGame mock = MockRepository.GenerateMock<IGame>();
            this.SetupMockSimple(mock, 'W', 1, player);
            mock.Expect(x => x.TryMarkMap(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Never();
            player.Register(mock);
            mock.Raise(x => x.Changed += null);
            mock.VerifyAllExpectations();
        }

        [Test]
        public void ShouldTryToUseAllButtons()
        {
            HashSet<KeyValuePair<int, int>> marks = new HashSet<KeyValuePair<int, int>>();
            ComputerPlayer player = new ComputerPlayer('X');
            IGame mock = MockRepository.GenerateMock<IGame>();
            mock.Expect(x => x.Winner).Return(' ').Repeat.Any();
            mock.Expect(x => x.Next).Return(player).Repeat.Any();
            mock.Expect(x => x.Turn).Do(
                new Func<uint>(() =>
                {
                    return (uint)marks.Count + 1;
                })).Repeat.Any();
            mock.Expect(x => x.TryMarkMap(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Do(
                new Func<int, int, bool>(
                    (a, b) =>
                    {
                        marks.Add(new KeyValuePair<int, int>(a, b));
                        return false;
                    })).Repeat.Any();
            player.Register(mock);
            mock.Raise(x => x.Changed += null);
            mock.VerifyAllExpectations();
            Assert.AreEqual(9, marks.Count);
        }

        [Test]
        public void ShouldNotRunForever()
        {
            ////If this Test Fails it will loop forever
            ComputerPlayer player = new ComputerPlayer('X');
            IGame mock = MockRepository.GenerateMock<IGame>();
            this.SetupMockSimple(mock, ' ', 1, player);
            mock.Expect(x => x.TryMarkMap(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(false).Repeat.Any();
            player.Register(mock);
            mock.Raise(x => x.Changed += null);
            mock.VerifyAllExpectations();
        }

        private void SetupMockSimple(IGame mock, char winner, uint turn, IPlayer next)
        {
            mock.Expect(x => x.Winner).Return(winner).Repeat.Any();
            mock.Expect(x => x.Turn).Return(turn).Repeat.Any();
            mock.Expect(x => x.Next).Return(next).Repeat.Any();
        }
    }
}
